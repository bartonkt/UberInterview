//
//  CustomUITabBarController.h
//  UberInterview
//
//  Created by Cheryl Barton on 1/1/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CustomUITabBarController : UITabBarController {
	
}

@end

